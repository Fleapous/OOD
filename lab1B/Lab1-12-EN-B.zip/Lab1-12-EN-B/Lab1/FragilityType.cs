﻿namespace Lab1
{
    public enum FragilityType
    {
        Glass = 0,
        Art = 1,
        Chemicals = 2,
        Volatiles = 3,
    }
}