﻿namespace ProcessManager
{
    public enum State
    {
        Created,
        Running,
        Finished
    }
}