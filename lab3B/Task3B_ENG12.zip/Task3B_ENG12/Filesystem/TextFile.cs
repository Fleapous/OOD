﻿using System.Text.RegularExpressions;

namespace Filesystem
{
    public abstract class TextFile : IFile
    {
        protected string name;
        public string Name => name;

        protected string content;

        public TextFile(string name, string content)
        {
            this.name = name;
            this.content = content;
        }

        public abstract string GetContent();
    }

    public class WindowsTextFile : TextFile
    {
        public WindowsTextFile(string name, string content) : base(name, content)
        {
        }

        public WindowsTextFile() : base("", "")
        {
        }

        public override string GetContent()
        {
            string tmp = content;
            for (int i = 0; i < content.Length; i++)
            {
                if (i % 8 == 0)
                {
                    tmp = content.Insert(i, "\n");
                }
            }
            return tmp;
        }
    }

    public class LinuxTextFile : TextFile
    {
        public LinuxTextFile(string name, string content) : base(name, content)
        {
        }

        public LinuxTextFile() : base("", "")
        {
        }

        public override string GetContent()
        {
            return content.ToLower();
        }
    }
    
}
