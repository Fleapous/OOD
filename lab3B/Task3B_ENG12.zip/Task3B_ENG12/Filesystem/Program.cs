﻿using System;
using System.Collections.Generic;
using System.ComponentModel;

namespace Filesystem
{
    class Program
    {
        static Root BuildFilesystem(List<string> directoriesPaths, List<string> directories, List<string> filePaths, List<string> fileNames, List<string> fileContents, ImainAbstract builder)
        {
            Root root = null; //create root

            root = builder.CreateRoot();
            //Add directories
            for (int i = 0; i < directories.Count; i++)
            {
                root.AddFile(builder.CreateDirectory(directories[i]), directoriesPaths[i]);
            }
            //Add text files
            for (int i = 0; i < fileNames.Count; i++)
            {
                root.AddFile(builder.CreateTextFile(fileNames[i], fileContents[i]), filePaths[i]);
            }
            return root;
        }

        static void Main(string[] args)
		{
            var directoriesPaths = new List<string> { "C:","C:/Users", "C:/Bad path" };
            var directories = new List<string> { "Users", "me", "badpath" };
            var filePaths = new List<string> { "C:/Users/me", "C:/Users/me"};
            var fileNames = new List<string> { "file2", "file1" };
            var fileContents = new List<string> { "UpPeRcAsE123", "veeeeeeeeeeeeeeeerrrryyyylooooongfiiiiiiiileeeee" };

            Console.WriteLine("--------------Windows--------------");
            var winRoot = BuildFilesystem(directoriesPaths, directories, filePaths, fileNames, fileContents, new Windows());
            var meDir = (winRoot.GetRootDir().Files.Find(f => f.Name == "Users") as Directory).Files.Find(f => f.Name == "me") as Directory;

            Console.WriteLine("Current filesystem: " + winRoot.FileSystem);
            Console.WriteLine(meDir.GetContent());
            foreach(var file in meDir.Files)
            {
                Console.WriteLine(file.GetContent());
            }

            Console.WriteLine("--------------Linux--------------");
            var linDirectoriesPaths = new List<string> { "root", "root/home/me/"};
            var linDirectories = new List<string> { "bin", "Desktop" };
            var linFilePaths = new List<string> { "root/home/me", "root/home/me" };
            var linFileNames = new List<string> { "file2", "file1" };
            var linFileContents = new List<string> { "LoWeRcAsE123", "veeeeeeeeeeeeeeeerrrryyyylooooongfiiiiiiiileeeee" };

            var linRoot = BuildFilesystem(linDirectoriesPaths, linDirectories, linFilePaths, linFileNames, linFileContents, new Linux());
            meDir = (linRoot.GetRootDir().Files.Find(f => f.Name == "home") as Directory).Files.Find(f => f.Name == "me") as Directory;

            Console.WriteLine("Current filesystem: " + linRoot.FileSystem);
            Console.WriteLine(meDir.GetContent());
            foreach (var file in meDir.Files)
            {
                Console.WriteLine(file.GetContent());
            }
        }
	}
}
