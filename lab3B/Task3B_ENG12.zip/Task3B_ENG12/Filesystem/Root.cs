﻿using System;
using System.IO;

namespace Filesystem
{
    public abstract class Root
    {
        protected Directory rootDir;
        public abstract void AddFile(IFile f, string path);

        public abstract string FileSystem { get; }
        public Directory GetRootDir() => rootDir;

        public Root(Directory root)
        {
            rootDir = root;
        }
    }

    public class WIndowsRoot : Root
    {
        public WIndowsRoot(Directory root) : base(root)
        {
        }

        public WIndowsRoot() : base(new WindowsDirectory())
        {
        }

        public override void AddFile(IFile f, string path)
        {
            rootDir.Files.Add(new WindowsTextFile(f.ToString(), path));
        }

        public override string FileSystem => rootDir.ToString();
    }

    public class LinuxRoot : Root
    {
        public LinuxRoot(Directory root) : base(root)
        {
        }

        public LinuxRoot() : base(new LinuxDirectory())
        {
        }

        public override void AddFile(IFile f, string path)
        {
            throw new NotImplementedException();
        }

        public override string FileSystem => rootDir.ToString();
    }
    
}
