﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Filesystem
{
    public abstract class Directory : IFile
    {
        protected List<IFile> files = new List<IFile>();
        public List<IFile> Files => files;
        protected string name;
        public string Name => name;

        public Directory(string name)
        {
            this.name = name;
        }

        public abstract string GetContent();
    }

    public class WindowsDirectory : Directory
    {
        public WindowsDirectory(string name) : base(name)
        {
        }

        public WindowsDirectory() : base("C:")
        {
        }

        public override string GetContent()
        {
            string tmp = "";
            for (int i = 0; i < Files.Count; i++)
            {
                if (files[i].ToString() != ".")
                {
                    tmp += Files[i].ToString();
                }
            }

            return tmp;
        }
    }

    public class LinuxDirectory : Directory
    {
        public LinuxDirectory(string name) : base(name)
        {
        }

        public LinuxDirectory() : base("root")
        {
        }

        public override string GetContent()
        {
            //return all the files in all the dirs in alphabetical
            throw new NotImplementedException();
        }
    }
}
