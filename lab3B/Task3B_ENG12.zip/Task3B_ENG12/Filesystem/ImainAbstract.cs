namespace Filesystem
{
    public interface ImainAbstract
    {
        TextFile CreateTextFile(string name, string content);
        Directory CreateDirectory(string name);
        Root CreateRoot();
    }

    public class Windows : ImainAbstract
    {
        public TextFile CreateTextFile(string name, string content)
        {
            return new WindowsTextFile(name, content);
        }

        public Directory CreateDirectory(string name)
        {
            return new WindowsDirectory(name);
        }

        public Root CreateRoot()
        {
            return new WIndowsRoot();
        }
    }

    public class Linux : ImainAbstract
    {
        public TextFile CreateTextFile(string name, string content)
        {
            return new LinuxTextFile(name, content);
        }

        public Directory CreateDirectory(string name)
        {
            return new LinuxDirectory(name);
        }

        public Root CreateRoot()
        {
            return new LinuxRoot();
        }
    }
}