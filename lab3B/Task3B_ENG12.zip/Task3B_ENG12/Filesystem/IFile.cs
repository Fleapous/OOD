﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Filesystem
{
    public interface IFile
    {
        string Name { get; }

        string GetContent();
    }
}
