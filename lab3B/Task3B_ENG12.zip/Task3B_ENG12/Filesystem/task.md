# Filesystems

Your task is to prepare filesystem interface for multiple Operating Systems. Your solution should support a possibility of creating additional platforms with filesystems if needed. The general interface should be platform independent, however their implementation may differ.

The solution consists of:
- Common interface `IFile` with `Name` and GetContent() method for TextFile and Directory (same as in Unix everything is a file)
- TextFile - with Name and GetContent() method
- Directory - with Name, Files and GetContent() method
- Root - with Filesystem, GetRootDir() and AddItem() methods
- Main and BuildFilesystem methods

## Platforms

- ### Windows
  1. TextFile - GetContent() prints out the content, but with line wrapping (insert newline `\n` every 8 characters)
  2. Directory - GetContent() returns list of names of all files and directories located in directory (non-recursively) in the order they have been added to directory, it also does not print out items whose name starts with a "." (dot).
  3. Root - AddItem() adds an item according to forward-slash separated path (eg. `/root/hello.txt`), if the path is invalid it prints out a warning and does nothing. If the file already exists it also does print out a warning. FileSystem is `NTFS`. Windows should be created with "C:" as it's root directory.

- ### Linux
  1. TextFile - GetContent() prints out the content, but in lowercase
  2. Directory - GetContent() returns list of names of all files and directories located in directory (non-recursively) in alphabetical order.
  3. Root - AddItem() adds an item according to forward-slash separated path, if the path is invalid it adds the missing directories. If the file exists it is overwritten. FileSystem is `Ext4`. Linux should be created with "root" as it's root directory.

## Task
1. Implement missing classes.
2. Complete the BuildFilesystem method, that prepares the filesystem according to provided configuration.

## Notes
- Solution should support unlimited varieties of filesystem types and objects.
- Adding those should be easy and it should be performed without modifying previously defined 
code, especially BuildFilesystem function.
- You can’t modify IFile,Root,TextFile and Directory classes.
- You can’t use switch or any other conditional operations on object types or object categories.